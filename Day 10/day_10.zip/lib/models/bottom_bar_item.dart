


import 'package:flutter/material.dart';

class BttmBarItem {

 late String label;
 late IconData icon;

 BttmBarItem({required this.label,required this.icon});
}