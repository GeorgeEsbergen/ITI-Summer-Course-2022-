


class Transaction {
  double? amount;
  Duration? duration;
 
  

  Transaction({this.amount, this.duration});
}
